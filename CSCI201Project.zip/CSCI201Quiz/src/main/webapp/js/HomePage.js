/**
 * 
 */
function getCategoryName() {
			$.ajax({
				url: "http://localhost:8080/CSCI201Quiz/category",
				method: "GET",
				dataType: "json",
				success: function(data) {
					// handle success response
				},
				error: function(jqXHR, textStatus, errorThrown) {
					// handle error response
				}
			});
		}